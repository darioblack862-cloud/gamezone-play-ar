GameZone Play AR - versión PS4 + PS5
- Inicio con PS4 y PS5 mezclados.
- Menú de tres líneas para filtrar PS4 o PS5.
- 42 juegos: 21 PS4 + 21 PS5.
- Portadas aportadas por el usuario para PS4 y PS5.
- Buscador, filtros, orden, favoritos, carrito, ofertas y detalles.
- Tema oscuro/claro con mando visual diferente.
- Sitio estático. No procesa pagos reales.
